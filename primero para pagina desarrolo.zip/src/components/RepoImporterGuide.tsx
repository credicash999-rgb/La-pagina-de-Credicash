import React, { useState } from 'react';
import { Github, Globe, Key, Upload, AlertTriangle, Check, Copy, ExternalLink, ArrowRight, ShieldCheck, Terminal } from 'lucide-react';

interface RepoImporterGuideProps {
  onAttemptCloneWithToken?: (token: string) => void;
}

export const RepoImporterGuide: React.FC<RepoImporterGuideProps> = ({ onAttemptCloneWithToken }) => {
  const [token, setToken] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const repoUrl = 'https://github.com/credicash999-rgb/La-pagina-de-Credicash.git';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Alert Header */}
      <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-6 shadow-xl relative overflow-hidden backdrop-blur-sm">
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-start gap-4">
          <div className="p-3 bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/30 shrink-0">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-bold text-amber-200">
              Estado de la Carga de Tu Repositorio CrediCash
            </h2>
            <p className="text-stone-300 text-sm leading-relaxed">
              Intentamos acceder a tu repositorio en <code className="bg-stone-900 px-2 py-1 rounded text-amber-300 font-mono text-xs">{repoUrl}</code>, pero el repositorio actualmente es <strong className="text-amber-200 underline">privado</strong> en GitHub y requiere credenciales de autenticación para clonarse.
            </p>
            <p className="text-stone-400 text-xs">
              ¡No te preocupes! Elige cualquiera de las 3 opciones siguientes para que podamos sincronizar tu código exacto e identificar los errores de conexión a tu base de datos:
            </p>
          </div>
        </div>
      </div>

      {/* 3 Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Option 1: Public Repo */}
        <div className="bg-[#1c180d] border border-amber-900/40 rounded-2xl p-6 flex flex-col justify-between hover:border-amber-500/40 transition-all shadow-lg group">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Opción 1 — Recomendada
              </span>
              <Globe className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100 mb-1">Cambiar a Repositorio Público</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Haz público tu repositorio en GitHub por unos minutos para que la plataforma clone los archivos automáticamente.
              </p>
            </div>
            <ol className="space-y-2 text-xs text-stone-300 list-decimal pl-4">
              <li>Ingresa a tu repo en GitHub.</li>
              <li>Ve a <strong>Settings</strong> → desplázate hasta <strong>Danger Zone</strong>.</li>
              <li>Haz clic en <strong>Change repository visibility</strong> → <strong>Make public</strong>.</li>
              <li>Avísame aquí cuando lo cambies.</li>
            </ol>
          </div>
          <a
            href="https://github.com/credicash999-rgb/La-pagina-de-Credicash/settings"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-md shadow-amber-500/10"
          >
            Abrir Configuración en GitHub
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Option 2: Personal Access Token */}
        <div className="bg-[#1c180d] border border-amber-900/40 rounded-2xl p-6 flex flex-col justify-between hover:border-amber-500/40 transition-all shadow-lg group">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-stone-800 text-stone-300 border border-stone-700">
                Opción 2 — Token Privado
              </span>
              <Key className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100 mb-1">Usar GitHub Access Token</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Genera un Personal Access Token (PAT) con permisos de lectura en GitHub y pégalo a continuación.
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-[11px] text-stone-400 block">Personal Access Token (ghp_...):</label>
              <input
                type="password"
                placeholder="ghp_xxxxxxx..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="w-full bg-stone-900/80 border border-stone-700 focus:border-amber-500 rounded-lg px-3 py-2 text-xs text-stone-100 placeholder-stone-600 outline-none transition-colors font-mono"
              />
            </div>
          </div>
          <button
            onClick={() => token && onAttemptCloneWithToken?.(token)}
            disabled={!token}
            className="mt-6 w-full py-2.5 px-4 rounded-xl bg-stone-800 hover:bg-amber-600 disabled:opacity-50 disabled:hover:bg-stone-800 text-stone-100 hover:text-amber-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-stone-700"
          >
            Clonar con Token
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Option 3: Direct File Paste / Upload */}
        <div className="bg-[#1c180d] border border-amber-900/40 rounded-2xl p-6 flex flex-col justify-between hover:border-amber-500/40 transition-all shadow-lg group">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-stone-800 text-stone-300 border border-stone-700">
                Opción 3 — Copiar Archivos
              </span>
              <Upload className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100 mb-1">Pegar / Subir Código Directo</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Pega aquí o en el chat el archivo de configuración de base de datos o variables de entorno (ej. <code className="text-amber-300 font-mono">db.js</code>, <code className="text-amber-300 font-mono">.env</code>, <code className="text-amber-300 font-mono">connection.ts</code>).
              </p>
            </div>
            <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800 text-xs text-stone-300 space-y-1">
              <p className="font-semibold text-amber-300">Archivos clave a revisar:</p>
              <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-stone-400">
                <li>Configuración DB (Host, Puerto, Usuario)</li>
                <li>Variables de entorno (DATABASE_URL / ENV)</li>
                <li>Controladores de conexión</li>
              </ul>
            </div>
          </div>
          <button
            onClick={() => copyToClipboard(repoUrl)}
            className="mt-6 w-full py-2.5 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-stone-700"
          >
            {copiedUrl ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" /> URL Copiada
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Copiar URL del Repo
              </>
            )}
          </button>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-[#1f1a0e] border border-amber-500/20 rounded-2xl p-5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-amber-400 shrink-0" />
          <p className="text-xs text-stone-300">
            Mientras nos compartes el acceso o el código de tu repositorio, ya dejamos lista la <strong className="text-amber-300">interfaz de desarrollo (#16140b, barra fija superior y etiqueta DEV / PRUEBAS)</strong> y el <strong className="text-amber-300">módulo interactivo de diagnóstico de base de datos</strong>.
          </p>
        </div>
      </div>
    </div>
  );
};
