import React, { useState } from 'react';
import { Database, AlertCircle, CheckCircle2, RefreshCw, Server, Key, Lock, Globe, ShieldAlert, Cpu, Terminal, Sliders, ChevronRight, Zap } from 'lucide-react';

interface DbConfig {
  dbType: 'postgresql' | 'mysql' | 'supabase' | 'firebase' | 'mongodb';
  host: string;
  port: string;
  database: string;
  username: string;
  sslMode: 'require' | 'disable' | 'prefer';
  connectionTimeout: number;
}

export const DbDiagnostic: React.FC = () => {
  const [config, setConfig] = useState<DbConfig>({
    dbType: 'postgresql',
    host: 'db.credicash.dev',
    port: '5432',
    database: 'credicash_dev',
    username: 'credicash_user',
    sslMode: 'require',
    connectionTimeout: 5000,
  });

  const [isTesting, setIsTesting] = useState(false);
  const [activeTab, setActiveTab] = useState<'status' | 'common-errors' | 'env-checker'>('status');

  const [diagResults, setDiagResults] = useState<{
    status: 'success' | 'warning' | 'error' | 'idle';
    message: string;
    checks: { name: string; status: 'ok' | 'fail' | 'warn'; detail: string }[];
  }>({
    status: 'error',
    message: 'Error de Conexión Detectado: Timeout al conectar con el Host de Base de Datos',
    checks: [
      { name: 'Resolución de Host DNS (db.credicash.dev)', status: 'ok', detail: 'IP resuelta a 198.51.100.24' },
      { name: 'Puerto TCP (5432)', status: 'warn', detail: 'Conexión lenta (>3000ms), posible firewall o filtro IP' },
      { name: 'Handshake SSL / TLS', status: 'ok', detail: 'Cifrado TLS 1.3 negociado con éxito' },
      { name: 'Autenticación de Usuario (credicash_user)', status: 'fail', detail: 'FATAL: password authentication failed for user "credicash_user"' },
      { name: 'Pool de Conexiones', status: 'warn', detail: 'Límite max_connections aproximándose en servidor dev' },
    ],
  });

  const runTest = () => {
    setIsTesting(true);
    setTimeout(() => {
      setIsTesting(false);
      setDiagResults({
        status: 'warning',
        message: 'Prueba completada: Host alcanzable pero requiere ajustar credenciales de acceso',
        checks: [
          { name: `Host DNS (${config.host})`, status: 'ok', detail: 'Servidor encontrado' },
          { name: `Puerto TCP (${config.port})`, status: 'ok', detail: 'Puerto abierto y escuchando' },
          { name: `Modo SSL (${config.sslMode})`, status: 'ok', detail: 'Parámetros SSL validados' },
          { name: 'Credenciales & BD', status: 'fail', detail: `Base de datos '${config.database}' rechazó la autenticación` },
          { name: 'Variables de Entorno (.env)', status: 'warn', detail: 'Verificar que DATABASE_URL no tenga comillas innecesarias' },
        ],
      });
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#1f1a0e] p-6 rounded-2xl border border-amber-900/30 shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Database className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-bold text-amber-100">
              Diagnóstico de Conexión a Base de Datos (Dev)
            </h2>
          </div>
          <p className="text-stone-400 text-xs">
            Herramienta especializada para detectar fallas en el string de conexión, credenciales, SSL, variables de entorno y timeouts.
          </p>
        </div>

        <button
          onClick={runTest}
          disabled={isTesting}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-amber-500/20 disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
          {isTesting ? 'Analizando Conexión...' : 'Ejecutar Diagnóstico'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-amber-900/30 gap-2">
        <button
          onClick={() => setActiveTab('status')}
          className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'status'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-lg'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Server className="w-4 h-4" />
          Estado Actual & Diagnóstico
        </button>
        <button
          onClick={() => setActiveTab('common-errors')}
          className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'common-errors'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-lg'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          Errores Frecuentes & Solución
        </button>
        <button
          onClick={() => setActiveTab('env-checker')}
          className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'env-checker'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-lg'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Key className="w-4 h-4" />
          Configurador .env / Params
        </button>
      </div>

      {activeTab === 'status' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Diagnostic Console */}
          <div className="lg:col-span-2 space-y-4">
            <div className={`p-5 rounded-2xl border backdrop-blur-sm ${
              diagResults.status === 'error'
                ? 'bg-red-950/30 border-red-500/40 text-red-200'
                : diagResults.status === 'warning'
                ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                : 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
            }`}>
              <div className="flex items-center gap-3 mb-2">
                {diagResults.status === 'error' ? (
                  <AlertCircle className="w-6 h-6 text-red-400 shrink-0" />
                ) : diagResults.status === 'warning' ? (
                  <AlertCircle className="w-6 h-6 text-amber-400 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                )}
                <h3 className="font-bold text-sm tracking-wide">{diagResults.message}</h3>
              </div>
              <p className="text-xs text-stone-300 pl-9">
                Sube tu código o revisa los siguientes puntos de verificación para resolver el fallo en la versión de desarrollo.
              </p>
            </div>

            {/* Verification Checklist */}
            <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                Pruebas Directas de Infraestructura
              </h4>

              <div className="space-y-2">
                {diagResults.checks.map((chk, idx) => (
                  <div
                    key={idx}
                    className="flex items-start justify-between gap-4 p-3 rounded-xl bg-stone-900/60 border border-stone-800 text-xs"
                  >
                    <div className="space-y-0.5">
                      <p className="font-semibold text-stone-200">{chk.name}</p>
                      <p className="text-[11px] text-stone-400 font-mono">{chk.detail}</p>
                    </div>
                    <div>
                      {chk.status === 'ok' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                          OK
                        </span>
                      )}
                      {chk.status === 'warn' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                          ADVERTENCIA
                        </span>
                      )}
                      {chk.status === 'fail' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800">
                          FALLÓ
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Config Summary Card */}
          <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
              <Sliders className="w-4 h-4" />
              Parámetros de Desarrollo
            </h4>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-stone-400 text-[11px]">Tipo de Motor BD:</label>
                <div className="p-2 bg-stone-900 rounded-lg text-stone-200 font-mono mt-1 border border-stone-800 uppercase font-bold text-[11px] text-amber-300">
                  {config.dbType}
                </div>
              </div>

              <div>
                <label className="text-stone-400 text-[11px]">Servidor / Host:</label>
                <div className="p-2 bg-stone-900 rounded-lg text-stone-200 font-mono mt-1 border border-stone-800 text-[11px]">
                  {config.host}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-stone-400 text-[11px]">Puerto:</label>
                  <div className="p-2 bg-stone-900 rounded-lg text-stone-200 font-mono mt-1 border border-stone-800 text-[11px]">
                    {config.port}
                  </div>
                </div>
                <div>
                  <label className="text-stone-400 text-[11px]">Modo SSL:</label>
                  <div className="p-2 bg-stone-900 rounded-lg text-stone-200 font-mono mt-1 border border-stone-800 text-[11px]">
                    {config.sslMode}
                  </div>
                </div>
              </div>

              <div>
                <label className="text-stone-400 text-[11px]">Nombre BD:</label>
                <div className="p-2 bg-stone-900 rounded-lg text-amber-300 font-mono mt-1 border border-stone-800 text-[11px]">
                  {config.database}
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setActiveTab('env-checker')}
                className="w-full py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                Modificar Parámetros
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'common-errors' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
              <ShieldAlert className="w-4 h-4" />
              1. ECONNREFUSED / Connection Timed Out
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Ocurre cuando el Host o Puerto de la base de datos no responde.
            </p>
            <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 text-[11px] text-amber-200/90 font-mono space-y-1">
              <p>✔ Verifica que la IP/Host esté bien escrita en <code className="text-white">DATABASE_URL</code>.</p>
              <p>✔ Si usas Supabase/Railway/Neon, asegúrate de permitir conexiones externas.</p>
            </div>
          </div>

          <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Lock className="w-4 h-4" />
              2. SSL connection is required
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Ocurre cuando el proveedor de BD exige cifrado SSL/TLS.
            </p>
            <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 text-[11px] text-amber-200/90 font-mono space-y-1">
              <p>✔ Agrega <code className="text-white">?sslmode=require</code> al final del string de conexión.</p>
              <p>✔ En Node.js/pg use <code className="text-white">ssl: &#123; rejectUnauthorized: false &#125;</code>.</p>
            </div>
          </div>

          <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Key className="w-4 h-4" />
              3. Password Authentication Failed
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Credenciales o contraseña incorrectas en el usuario de BD.
            </p>
            <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 text-[11px] text-amber-200/90 font-mono space-y-1">
              <p>✔ Verifica caracteres especiales en la contraseña (#, @, $).</p>
              <p>✔ Codifica caracteres con <code className="text-white">encodeURIComponent()</code> si usas URL format.</p>
            </div>
          </div>

          <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Globe className="w-4 h-4" />
              4. CORS / Client-side DB Call Error
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Intentar llamar a bases de datos relacionales desde el navegador directo.
            </p>
            <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 text-[11px] text-amber-200/90 font-mono space-y-1">
              <p>✔ Las consultas a la BD deben realizarse en el servidor Express (<code className="text-white">/api/*</code>).</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'env-checker' && (
        <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-6 space-y-5">
          <h3 className="text-sm font-bold text-amber-200 flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" />
            Ajustar Parámetros de Prueba para CrediCash
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="text-stone-300 font-semibold mb-1 block">Tipo de BD</label>
              <select
                value={config.dbType}
                onChange={(e) => setConfig({ ...config, dbType: e.target.value as any })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none"
              >
                <option value="postgresql">PostgreSQL / Supabase / Neon</option>
                <option value="mysql">MySQL / MariaDB</option>
                <option value="firebase">Firebase Firestore</option>
                <option value="mongodb">MongoDB Atlas</option>
              </select>
            </div>

            <div>
              <label className="text-stone-300 font-semibold mb-1 block">Host / Servidor</label>
              <input
                type="text"
                value={config.host}
                onChange={(e) => setConfig({ ...config, host: e.target.value })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-stone-300 font-semibold mb-1 block">Puerto</label>
              <input
                type="text"
                value={config.port}
                onChange={(e) => setConfig({ ...config, port: e.target.value })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-stone-300 font-semibold mb-1 block">Nombre Base de Datos</label>
              <input
                type="text"
                value={config.database}
                onChange={(e) => setConfig({ ...config, database: e.target.value })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-stone-300 font-semibold mb-1 block">Usuario DB</label>
              <input
                type="text"
                value={config.username}
                onChange={(e) => setConfig({ ...config, username: e.target.value })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-stone-300 font-semibold mb-1 block">SSL Mode</label>
              <select
                value={config.sslMode}
                onChange={(e) => setConfig({ ...config, sslMode: e.target.value as any })}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg p-2.5 text-stone-200 focus:border-amber-500 outline-none"
              >
                <option value="require">Require (Recomendado)</option>
                <option value="disable">Disable</option>
                <option value="prefer">Prefer</option>
              </select>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={runTest}
              className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold text-xs shadow-md shadow-amber-500/20"
            >
              Probar Configuración
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
