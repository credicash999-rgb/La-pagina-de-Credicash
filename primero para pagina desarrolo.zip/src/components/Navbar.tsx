import React from 'react';
import { Database, Shield, LayoutDashboard, CreditCard, Users, Settings } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  dbStatus: 'connecting' | 'connected' | 'error';
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, dbStatus }) => {
  return (
    <header className="pt-10 bg-[#1f1a0e] border-b border-amber-900/30 sticky top-0 z-40 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Dev Badge */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-amber-950 font-black text-xl shadow-lg shadow-amber-500/10">
                C
              </div>
              <span className="text-xl font-bold tracking-tight text-amber-100">
                Credi<span className="text-amber-400">Cash</span>
              </span>
            </div>

            {/* Insignia en la Barra de Navegación: DEV / PRUEBAS */}
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider shadow-inner">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              DEV / PRUEBAS
            </span>
          </div>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                activeTab === 'dashboard'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-stone-300 hover:text-amber-200 hover:bg-stone-800/50'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Panel General
            </button>

            <button
              onClick={() => setActiveTab('db-diagnostics')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                activeTab === 'db-diagnostics'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-stone-300 hover:text-amber-200 hover:bg-stone-800/50'
              }`}
            >
              <Database className="w-4 h-4 text-amber-400" />
              Diagnóstico de Base de Datos
            </button>

            <button
              onClick={() => setActiveTab('repo-instructions')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                activeTab === 'repo-instructions'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-stone-300 hover:text-amber-200 hover:bg-stone-800/50'
              }`}
            >
              <Shield className="w-4 h-4 text-amber-400" />
              Conectar Repositorio GitHub
            </button>
          </nav>

          {/* Right Status Badge & Corporate Action */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('db-diagnostics')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                dbStatus === 'connected'
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50'
                  : dbStatus === 'connecting'
                  ? 'bg-amber-950/80 text-amber-300 border-amber-600/50 animate-pulse'
                  : 'bg-red-950/80 text-red-300 border-red-600/50'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>
                {dbStatus === 'connected'
                  ? 'BD Conectada'
                  : dbStatus === 'connecting'
                  ? 'Comprobando BD...'
                  : 'Falla BD Detectada'}
              </span>
            </button>

            <button 
              onClick={() => setActiveTab('db-diagnostics')}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-amber-950 transition-colors shadow-md shadow-amber-500/20"
            >
              Revisar Conexión
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
