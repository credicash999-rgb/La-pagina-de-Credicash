import React from 'react';
import { TrendingUp, Users, DollarSign, CreditCard, ArrowUpRight, ArrowDownRight, FileText, CheckCircle2, AlertCircle, Clock, Search, Filter } from 'lucide-react';

export const CrediCashDashboard: React.FC<{ onNavigateToDiag: () => void }> = ({ onNavigateToDiag }) => {
  const stats = [
    { title: 'Créditos Aprobados (Dev)', value: '$128,450.00', change: '+12.5%', isUp: true, icon: DollarSign },
    { title: 'Solicitudes en Revisión', value: '34', change: '-3', isUp: false, icon: FileText },
    { title: 'Clientes Activos', value: '1,280', change: '+8.4%', isUp: true, icon: Users },
    { title: 'Tasa de Recuperación', value: '98.2%', change: '+0.5%', isUp: true, icon: TrendingUp },
  ];

  const recentTransactions = [
    { id: 'CRD-8841', client: 'Carlos Mendoza', amount: '$2,500.00', type: 'Préstamo Personal', status: 'Aprobado', date: 'Hoy, 10:42 AM' },
    { id: 'CRD-8840', client: 'Empresa Soluciones S.A.', amount: '$15,000.00', type: 'Crédito PyME', status: 'En Evaluación', date: 'Hoy, 09:15 AM' },
    { id: 'CRD-8839', client: 'Ana María Torres', amount: '$1,200.00', type: 'Microcrédito', status: 'Aprobado', date: 'Ayer, 16:30 PM' },
    { id: 'CRD-8838', client: 'Roberto Gómez', amount: '$5,000.00', type: 'Vehicular', status: 'Revisión BD', date: 'Ayer, 14:10 PM' },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Dev Environment Notice Banner inside Dashboard */}
      <div className="bg-[#241e0f] border-l-4 border-amber-400 p-4 rounded-xl shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/20 text-amber-300 rounded-lg shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-amber-200">
              Entorno de Pruebas CrediCash Activo (#16140b)
            </p>
            <p className="text-[11px] text-stone-400">
              Fondo cálido ámbar/dorado oscuro habilitado con alto contraste de tablas, textos y botones corporativos.
            </p>
          </div>
        </div>

        <button
          onClick={onNavigateToDiag}
          className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-amber-950 transition-colors shadow-md shrink-0"
        >
          Diagnóstico de Base de Datos
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="bg-[#1c180d] border border-amber-900/30 rounded-2xl p-5 hover:border-amber-500/40 transition-all shadow-lg space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-stone-400 text-xs font-semibold">{item.title}</span>
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-bold text-amber-100">{item.value}</span>
                <span
                  className={`text-xs font-bold flex items-center ${
                    item.isUp ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {item.isUp ? <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" /> : <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />}
                  {item.change}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Transactions Table */}
      <div className="bg-[#1c180d] border border-amber-900/30 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-6 border-b border-amber-900/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-amber-100 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-amber-400" />
              Solicitudes Recientes de Crédito (Base de Datos Dev)
            </h3>
            <p className="text-stone-400 text-xs mt-0.5">
              Registro de créditos procesados en el sistema de desarrollo.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-500" />
              <input
                type="text"
                placeholder="Buscar crédito..."
                className="bg-stone-900 border border-stone-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-stone-200 placeholder-stone-600 focus:border-amber-500 outline-none w-48"
              />
            </div>
            <button className="p-1.5 bg-stone-900 border border-stone-800 rounded-lg text-stone-400 hover:text-amber-300">
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#241e0f] text-stone-300 uppercase tracking-wider font-semibold border-b border-amber-900/30">
              <tr>
                <th className="py-3.5 px-6">ID Crédito</th>
                <th className="py-3.5 px-6">Cliente</th>
                <th className="py-3.5 px-6">Tipo</th>
                <th className="py-3.5 px-6">Monto</th>
                <th className="py-3.5 px-6">Estado</th>
                <th className="py-3.5 px-6">Fecha</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-900/20 text-stone-300">
              {recentTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-amber-500/5 transition-colors">
                  <td className="py-4 px-6 font-mono text-amber-300 font-bold">{tx.id}</td>
                  <td className="py-4 px-6 font-medium text-stone-100">{tx.client}</td>
                  <td className="py-4 px-6 text-stone-400">{tx.type}</td>
                  <td className="py-4 px-6 font-bold text-amber-200">{tx.amount}</td>
                  <td className="py-4 px-6">
                    {tx.status === 'Aprobado' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        <CheckCircle2 className="w-3 h-3" /> Aprobado
                      </span>
                    ) : tx.status === 'En Evaluación' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                        <Clock className="w-3 h-3" /> Evaluación
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-950/80 text-amber-400 border border-amber-700/80">
                        <AlertCircle className="w-3 h-3" /> Revisión BD
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6 text-stone-400">{tx.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
