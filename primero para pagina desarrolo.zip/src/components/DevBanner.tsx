import React from 'react';
import { FlaskConical } from 'lucide-react';

export const DevBanner: React.FC = () => {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-amber-400 text-amber-950 font-semibold text-xs sm:text-sm py-2 px-4 shadow-md flex items-center justify-center gap-2 border-b border-amber-500/50">
      <FlaskConical className="w-4 h-4 shrink-0 text-amber-950 animate-pulse" />
      <span className="text-center tracking-wide">
        🧪 MODO DESARROLLO / PRUEBAS — Esta es la versión de desarrollo para realizar pruebas sin afectar producción.
      </span>
    </div>
  );
};
